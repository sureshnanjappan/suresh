package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Teacher;
import com.example.demo.error.NotFoundException;

import com.example.demo.repository.TeacherRepository;
import com.example.demo.service.TeacherService;

@RestController
public class TeacherController {
	
	@Autowired
	
	private TeacherService teacherservice;
	
	@Autowired
	private TeacherRepository teacherRepository;
	
	@PostMapping("/teacher")
	
	public ResponseEntity<Teacher> addTeacher(@Valid @RequestBody Teacher teacher) {
		
		Teacher teacher1=teacherservice.addTeacher(teacher);
		return new ResponseEntity<>(teacher1,HttpStatus.CREATED);
	}
	@GetMapping("/teacher")
	 
	public List<Teacher>getAllTeacher(){
		return teacherservice.getAllTeacher();
	}
	@GetMapping("/teacher/{tid}")
	
	public Teacher getTeacherById(@PathVariable("tid") Integer tid,@RequestBody Teacher teacher) throws NotFoundException {
		return teacherservice.getTeacherById(tid,teacher);
	}
	
	@DeleteMapping("/teacher/{tid}")
	
	public String deleteTeacher(@PathVariable("tid") Integer tid) throws NotFoundException {
		teacherservice.deleteTeacher(tid);
		return "record is deleted";
	}
	@PutMapping("/teacher/{tid}")
	public Teacher updateTeacher(@PathVariable("tid") Integer tid,@RequestBody Teacher teacher) throws NotFoundException {
		return teacherservice. updateTeacher(tid,teacher);
	
	}
	
	@GetMapping("/teachertotalsalary")
	 public float teachertotalsalary() {
		 return teacherRepository.totalsalary();
	 }
	

}
