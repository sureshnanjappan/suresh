package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.entity.Student;

import com.example.demo.error.NotFoundException;
import com.example.demo.repository.StudentRepository;

@Service

public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentRepository studentRepository;

	@Override
	public Student addStudent(Student student) {
	
		return studentRepository.save(student);
	}

	@Override
	public List<Student> getAllStudents() {
	
		return studentRepository.findAll();
	}

	@Override
	public Student getStudentById(Integer sid) throws NotFoundException {
	Optional<Student>student= studentRepository.findById(sid);
		
		
		if(!student.isPresent()) {
			throw new NotFoundException("student not found");
			
		}
		
			
		return studentRepository.findById(sid).get();
	}
	

	@Override
	public void deleteStudentById(Integer sid) throws NotFoundException {
		Optional<Student>student= studentRepository.findById(sid);
		
		
		if(!student.isPresent()) {
			throw new NotFoundException("student not found");
			
		}
		studentRepository.deleteById(sid);
		
		
		
	}

	@Override
	public Student updateStudent(Integer sid, Student student) throws NotFoundException {
		
		Optional<Student> student1=studentRepository.findById(sid);
		if(!student1.isPresent())
			throw new NotFoundException("student not found");
		
		else {
			Student student2=studentRepository.findById(sid).get();
		
		
		if( student2.getStudentName()!=null) 
			student2.setStudentName(student.getStudentName());
		
		if( student2.getStudentAddress()!=null) 
			student2.setStudentAddress(student.getStudentAddress());
		
		if( student2.getStudentAge()!=0) 
			student2.setStudentAge(student.getStudentAge());
		
		if( student2.getStudentEmail()!=null)
			student2.setStudentEmail(student.getStudentEmail());
		 
		
		if( student2.getStudentMobileNo()!=null)
			student2.setStudentMobileNo(student.getStudentMobileNo());
		

     return studentRepository.save(student2);
		
	}
		
}
	
	
	
	
	

	
	

}
 