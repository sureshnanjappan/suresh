package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Subject;
import com.example.demo.error.NotFoundException;

import com.example.demo.service.SubjectService;

@RestController

public class SubjectController {

	
	@Autowired
	private SubjectService subjectservice;
	
	@PostMapping("/subject")
	public ResponseEntity<Subject> addSubject(@Valid @RequestBody Subject subject) {
	
	Subject subject1=subjectservice.addSubject(subject);	
		return new ResponseEntity<>(subject1,HttpStatus.CREATED);
	}
	
	@GetMapping("/subject")
	
	public List<Subject>getAllSubject(){
		return subjectservice.getAllSubject();
	}
	@GetMapping("/subject/{subid}")
	public Subject getSubjectById(@PathVariable ("subid") Integer subid,@RequestBody Subject subject) throws NotFoundException {
		return subjectservice.getSubjectById(subid,subject);
	}
	
	@DeleteMapping("/subject/{subid}")
	public String deleteSubjectById(@PathVariable("subid") Integer subid , @RequestBody Subject subject) throws NotFoundException {
		
		subjectservice.deleteSubjectById(subid,subject);
		return "record is deleted";
		
	}
	
	@PutMapping("subject/{subid}")
	public Subject updateSubject(@PathVariable("subid") Integer subid,@RequestBody Subject subject) throws NotFoundException {
		return subjectservice.updateSubject(subid,subject);
	}
	
	@PutMapping("/subject/{subid}/student/{stuid}")
	
	public Subject enrolledStudentsToSubject(@PathVariable ("subid")Integer subid,@PathVariable("stuid") Integer stuid) throws NotFoundException, NotFoundException {
		return subjectservice.enrolledStudentsToSubject(subid,stuid);
	}
	
	@PutMapping("/subject/{subid}/teacher/{tid}")
	public Subject assignSubjectToTeacher(@PathVariable("subid")Integer subid,@PathVariable("tid")Integer tid) throws NotFoundException, NotFoundException {
		return subjectservice.assignSubjectToTeacher(subid,tid);
	}
	
	
	
}
