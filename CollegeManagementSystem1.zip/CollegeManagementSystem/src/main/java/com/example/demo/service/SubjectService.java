package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Subject;
import com.example.demo.error.NotFoundException;


public interface SubjectService {

	Subject addSubject(Subject subject);

	List<Subject> getAllSubject();

	Subject getSubjectById(Integer subid, Subject subject) throws NotFoundException;

	void deleteSubjectById(Integer subid, Subject subject) throws NotFoundException;

	Subject updateSubject(Integer subid, Subject subject) throws NotFoundException;

	Subject enrolledStudentsToSubject(Integer subid, Integer stuid) throws NotFoundException, NotFoundException;

	Subject assignSubjectToTeacher(Integer subid, Integer tid) throws NotFoundException, NotFoundException;

}
