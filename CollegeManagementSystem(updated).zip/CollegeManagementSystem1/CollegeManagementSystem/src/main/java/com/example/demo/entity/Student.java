package com.example.demo.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity

public class Student {
	
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private Integer studentId;
	
	@NotEmpty(message = "student name should not be empty")
	
	private String studentName;
	@NotEmpty(message = "student mobile no should not be empty")
	private String studentMobileNo;
	@NotEmpty(message = "student address should not be empty")
	
	private String studentAddress;
	@Email(message="invalid email imput")
	
	private String studentEmail;
	
	@Min(value=18 ,message="student age shoud greater than 17")
	private int studentAge;
	
	@Min(value=1000,message = "Fees should be Greater Than 1000")
	private float studentFees;
	
	@JsonIgnore
	
	@ManyToMany
	
	private Set<Subject> subject=new HashSet<>();
	
	public Set<Subject> getSubject() {
		return subject;
	}
	public void setSubject(Set<Subject> subject) {
		this.subject = subject;
	}
	public Integer getStudentId() {
		return studentId;
	}
	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentMobileNo() {
		return studentMobileNo;
	}
	public void setStudentMobileNo(String studentMobileNo) {
		this.studentMobileNo = studentMobileNo;
	}
	public String getStudentAddress() {
		return studentAddress;
	}
	public void setStudentAddress(String studentAddress) {
		this.studentAddress = studentAddress;
	}
	public String getStudentEmail() {
		return studentEmail;
	}
	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}
	public int getStudentAge() {
		return studentAge;
	}
	public void setStudentAge(int studentAge) {
		this.studentAge = studentAge;
	}
	public float getStudentFees() {
		return studentFees;
	}
	public void setStudentFees(float studentFees) {
		this.studentFees = studentFees;
	}
	
	
	
	
	

}
