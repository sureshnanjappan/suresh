package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Student;
import com.example.demo.entity.Subject;
import com.example.demo.entity.Teacher;
import com.example.demo.error.NotFoundException;

import com.example.demo.repository.StudentRepository;
import com.example.demo.repository.SubjectRepository;
import com.example.demo.repository.TeacherRepository;

@Service

public class SubjectServiceImpl implements SubjectService{

	
	@Autowired
	private SubjectRepository subjectRepository;
	
	@Autowired
	private StudentRepository studentRepository;
	
	@Autowired
	private TeacherRepository teacherRepository;
	

	@Override
	public Subject addSubject(Subject subject) {
		
		return subjectRepository.save(subject);
	}

	@Override
	public List<Subject> getAllSubject() {
		// TODO Auto-generated method stub
		return subjectRepository.findAll();
	}

	@Override
	public Subject getSubjectById(Integer subid) throws NotFoundException {
		
		Optional<Subject>subject1=subjectRepository.findById(subid);
		if(!subject1.isPresent())
			throw new NotFoundException("subject not found");
		
		else
		return subjectRepository.findById(subid).get();
	}

	@Override
	public void deleteSubjectById(Integer subid) throws NotFoundException {
		
		Optional<Subject>subject1=subjectRepository.findById(subid);
		if(!subject1.isPresent())
			throw new NotFoundException("subject not found");
		
		else
		subjectRepository.deleteById(subid);
		
		
		
	}

	@Override
	public Subject updateSubject(Integer subid, Subject subject) throws NotFoundException {
		
		Optional<Subject>subject1=subjectRepository.findById(subid);
		if(!subject1.isPresent())
			throw new NotFoundException("subject not found");
		else {
			Subject subject2=subjectRepository.findById(subid).get();
			
			
			if( subject2.getSubjectName()!=null)
				subject2.setSubjectName(subject.getSubjectName());
			
			return subjectRepository.save(subject2);
		}
	
		
	}

	@Override
	public Subject enrolledStudentsToSubject(Integer subid, Integer stuid) throws NotFoundException, NotFoundException {
		
		
		
		Optional<Subject>subject1=subjectRepository.findById(subid);
		if(!subject1.isPresent())
			throw new NotFoundException("subject not found");
		
		Optional<Student>student1=studentRepository.findById(stuid);
		if(!subject1.isPresent())
			throw new NotFoundException("student not found");
		
		else {
			Subject subject2=subjectRepository.findById(subid).get();
		
		Subject subject =subjectRepository.findById(subid).get();
		Student student= studentRepository.findById(stuid).get();
		subject.enrollStudent(student);
		
		
		return subjectRepository.save(subject) ;
	}
	}

	@Override
	public Subject assignSubjectToTeacher(Integer subid, Integer tid) throws NotFoundException, NotFoundException {
		
		
		Optional<Subject>subject1=subjectRepository.findById(subid);
		if(!subject1.isPresent())
			throw new NotFoundException("subject not found");
		
		Optional<Teacher>teacher1=teacherRepository.findById(tid);
		if(!teacher1.isPresent())
			throw new NotFoundException("teacher not found");
		
		
		else {
			Subject subject2=subjectRepository.findById(subid).get();
	
		Subject subject=subjectRepository.findById(subid).get();
		Teacher teacher=teacherRepository.findById(tid).get();
		subject.assignTeacher(teacher);
		
		return subjectRepository.save(subject);
	}
	}
	
}
