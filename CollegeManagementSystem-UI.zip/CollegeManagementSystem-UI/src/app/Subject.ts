import { Student } from './student';
import { Teacher } from './Teacher';

export class Subject {
    subjectId!: number;
    subjectName!: string;
    teacher!: Teacher;
    enrolledStudents!:Student[];
}