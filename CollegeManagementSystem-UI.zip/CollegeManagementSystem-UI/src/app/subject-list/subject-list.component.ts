import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { StudentService } from '../student.service';
import { Subject } from '../Subject';

@Component({
  selector: 'app-subject-list',
  templateUrl: './subject-list.component.html',
  styleUrls: ['./subject-list.component.css']
})
export class SubjectListComponent implements OnInit {

  subject!: Observable<Subject[]>;

  constructor(private ss: StudentService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.subject = this.ss.getSubjectList();
  }

  deleteSubject(id: number) {
    this.ss.deleteSubject(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  enrollStudent(id:number){
    this.router.navigate(['/student-enroll',id])
  }

  subjectDetails(id: number){
    this.router.navigate(['/subj-detail', id]);
  }
  updateSubject(id:number){
  
    this.router.navigate(['/update-subj',id]);
  }
  assignTeacher(id:number){
  debugger
    this.router.navigate(['/assign-teacher',id]);
  }
  enrollNewStudent(id:number){
    this.router.navigate(['/enrolled-students',id]);
  }
  
  
}
