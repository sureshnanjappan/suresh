import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';


import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { StudentListComponent } from './student-list/student-list.component';
import { CreateStudentComponent } from './create-student/create-student.component';

import { StudentDetailsComponent } from './student-details/student-details.component';

import { CreateTeacherComponent } from './create-teacher/create-teacher.component';
import { CreateSubjectComponent } from './create-subject/create-subject.component';
import { TeacherDetailsComponent } from './teacher-details/teacher-details.component';
import { SubjectDetailsComponent } from './subject-details/subject-details.component';
import { UpdateTeacherComponent } from './update-teacher/update-teacher.component';
import { UpdateSubjectComponent } from './update-subject/update-subject.component';
import { TeacherListComponent } from './teacher-list/teacher-list.component';
import { SubjectListComponent } from './subject-list/subject-list.component';
import { UpdateStudentComponent } from './update-student/update-student.component';


@NgModule({
  declarations: [
    AppComponent,
    StudentListComponent,
    CreateStudentComponent,
    UpdateStudentComponent,
    StudentDetailsComponent,
    CreateTeacherComponent,
    CreateSubjectComponent,
    TeacherDetailsComponent,
    SubjectDetailsComponent,
    UpdateTeacherComponent,
    UpdateSubjectComponent,
    TeacherListComponent,
    SubjectListComponent,
  
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
