import { Component, OnInit } from '@angular/core';
import { Subject } from '../Subject';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-subject-details',
  templateUrl: './subject-details.component.html',
  styleUrls: ['./subject-details.component.css']
})
export class SubjectDetailsComponent implements OnInit {

  id!: number;
subject!: Subject;
  isnotnull:boolean=false;

  constructor(private route: ActivatedRoute,private router: Router,
    private es: StudentService) { }

  ngOnInit() {

    this.subject = new Subject();
    this.isnotnull=true;
    this.id = this.route.snapshot.params['id'];
    
    this.es.getSubject(this.id)
      .subscribe(data => {
        console.log(data)
        this.subject = data;
      }, error => console.log("server not responding"));
  }

subject_list(){
    this.router.navigate(['subjects']);
  }
}
