import { Component, OnInit } from '@angular/core';
import { Teacher } from '../Teacher';
import { StudentService } from '../student.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-teacher',
  templateUrl: './create-teacher.component.html',
  styleUrls: ['./create-teacher.component.css']
})
export class CreateTeacherComponent implements OnInit {
  teacher: Teacher=new Teacher();
  constructor(private es: StudentService,
    private router: Router) { }

  ngOnInit(): void {
  }
  save() {
  
    this.es.createTeacher(this.teacher)
      .subscribe((data:any) => {
        
        alert('posted successfully')}, error => {
         
          alert('server not responding')});
    
    this.gotoList();
  }
gotoList() {
    this.router.navigate(['/teachers']);
  }
}


