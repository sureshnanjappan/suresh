import { Component, OnInit } from '@angular/core';
import { Subject } from '../Subject';
import { Teacher } from '../Teacher';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-assign-teacher',
  templateUrl: './assign-teacher.component.html',
  styleUrls: ['./assign-teacher.component.css']
})
export class AssignTeacherComponent implements OnInit {

  subid!: number;
  teachid!: number;
  subject!: Subject;
  teachers!: Teacher[]; // add teachers property
  submitted = false; // define the submitted property

  constructor(private route: ActivatedRoute, private router: Router,
              private studentService: StudentService) { }

  ngOnInit() {
    this.subject = new Subject();
    this.subid = this.route.snapshot.params['id'];
    this.studentService.getSubject(this.subid)
      .subscribe(data => {
        console.log(data)
        this.subject = data;
      }, error => console.log(error));
    this.studentService.getTeacherList()// fetch the list of teachers
      .subscribe(data => {
        console.log(data)
        this.teachers = data;
      }, error => console.log(error));
  }

  updateSubject(teachid:number) {
    this.studentService.assignTeacher(this.subid,teachid)
      .subscribe((data:any) => {
        this.subject.teacher=data;
        console.log(data)
      }, error => console.log(error));
    this.gotoList();
  }

  onSubmit() {
    this.updateSubject(this.teachid); // use teachid property
  }
  
  gotoList() {
    this.router.navigate(['/subjects']);
  }
  onInputChange(){
  }
}
