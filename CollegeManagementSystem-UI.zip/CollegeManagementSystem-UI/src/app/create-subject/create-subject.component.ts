import { Component, OnInit } from '@angular/core';
import { Subject } from '../Subject';
import { StudentService } from '../student.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-subject',
  templateUrl: './create-subject.component.html',
  styleUrls: ['./create-subject.component.css']
})
export class CreateSubjectComponent implements OnInit {

  subject: Subject=new Subject();
  constructor(private es: StudentService,
    private router: Router) { }

  ngOnInit(): void {
  }
  save() {
  
    this.es.createSubject(this.subject)
      .subscribe((data:any) => {
        
        alert('posted successfully')}, error => {
         
          alert('server not responding')});
    
    this.gotoList();
  }
gotoList() {
    this.router.navigate(['/subjects']);
  }
}