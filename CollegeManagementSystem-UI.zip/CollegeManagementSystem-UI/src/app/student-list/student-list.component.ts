
import { Observable } from "rxjs";

import { Router } from '@angular/router';
import { Component, OnInit } from "@angular/core";
import { Student } from '../student';
import { StudentService } from '../student.service';


@Component({
  selector: "app-student-list",
  templateUrl: "./Student-list.component.html",
  styleUrls: ["./Student-list.component.css"]
})
export class StudentListComponent implements OnInit {
  student!: Observable<Student[]>;

  constructor(private es: StudentService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.student = this.es.getStudentList();
  }

  deleteStudent(id: number) {
    this.es.deleteStudent(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  studentDetails(id: number){
    this.router.navigate(['/emp-detail', id]);
  }
  updateStudent(id:number){
    debugger
    this.router.navigate(['/update-emp',id]);
  }
}