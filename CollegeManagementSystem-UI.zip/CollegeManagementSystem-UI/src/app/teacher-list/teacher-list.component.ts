import { Component, OnInit } from '@angular/core';
import { Teacher } from '../Teacher';
import { Observable } from 'rxjs';
import { StudentService } from '../student.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-teacher-list',
  templateUrl: './teacher-list.component.html',
  styleUrls: ['./teacher-list.component.css']
})
export class TeacherListComponent implements OnInit {

 teacher!: Observable<Teacher[]>;

  constructor(private ss: StudentService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.teacher = this.ss.getTeacherList();
  }

  deleteTeacher(id: number) {
    this.ss.deleteTeacher(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  teacherDetails(id: number){
    this.router.navigate(['/teach-detail', id]);
  }
  updateTeacher(id:number){
    debugger
    this.router.navigate(['/update-teach',id]);
  }
}
