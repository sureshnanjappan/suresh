import { Component, OnInit } from '@angular/core';
import { Teacher } from '../Teacher';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-update-teacher',
  templateUrl: './update-teacher.component.html',
  styleUrls: ['./update-teacher.component.css']
})
export class UpdateTeacherComponent implements OnInit {

  id!: number;
  teacher!: Teacher;
  submitted = false; // define the submitted property

  constructor(private route: ActivatedRoute, private router: Router,
              private StudentService: StudentService) { }

  ngOnInit() {
    this.teacher = new Teacher();
debugger
    this.id = this.route.snapshot.params['id'];

    this.StudentService.getTeacher(this.id)
      .subscribe(data => {
        console.log(data)
        this.teacher = data;
      }, error => console.log(error));
  }

  updateTeacher() {
    this.StudentService.updateTeacher(this.id, this.teacher)
      .subscribe(data => console.log(data), error => console.log(error));
    this.gotoList();
  }

  onSubmit() {

    // this.submitted = true;
    this.updateTeacher();
  }

  gotoList() {
    this.router.navigate(['/teachers']);
  }
}
