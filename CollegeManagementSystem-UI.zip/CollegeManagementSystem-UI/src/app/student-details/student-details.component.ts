
import { Component, OnInit, Input } from '@angular/core';


import { Router, ActivatedRoute } from '@angular/router';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-details',
  templateUrl: './student-details.component.html',
  styleUrls: ['./student-details.component.css']
})
export class StudentDetailsComponent implements OnInit {

  id!: number;
  student!: Student;
  isnotnull:boolean=false;

  constructor(private route: ActivatedRoute,private router: Router,
    private es: StudentService) { }

  ngOnInit() {
   
    this.student = new Student();
    this.isnotnull=true;
    this.id = this.route.snapshot.params['id'];
    
    this.es.getStudent(this.id)
      .subscribe(data => {
        console.log(data)
        this.student = data;
      }, error => console.log("server not responding"));
  }

  Student_list(){
    this.router.navigate(['students']);
  }
}

