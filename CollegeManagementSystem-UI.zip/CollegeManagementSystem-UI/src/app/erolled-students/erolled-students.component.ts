import { Component, OnInit } from '@angular/core';
import { Subject } from '../Subject';
import { Student } from '../student';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-erolled-students',
  templateUrl: './erolled-students.component.html',
  styleUrls: ['./erolled-students.component.css']
})
export class ErolledStudentsComponent implements OnInit {

  subid!: number;
  studentId!: number;
  subject!: Subject;
  students!: Student[]; // add teachers property
  submitted = false; // define the submitted property

  constructor(private route: ActivatedRoute, private router: Router,
              private studentService: StudentService) { }

  ngOnInit() {
    this.subject = new Subject();
    this.subid = this.route.snapshot.params['id'];
    this.studentService.getSubject(this.subid)
      .subscribe(data => {
        console.log(data)
        this.subject = data;
      }, error => console.log(error));
    this.studentService.getStudentList()// fetch the list of students
      .subscribe(data => {
        console.log(data)
        this.students = data;
      }, error => console.log(error));
  }

  updateSubject(studentId:number) {
    this.studentService.enrollStudent(this.subid,studentId)
      .subscribe((data:any) => {
        this.subject.teacher=data;
        console.log(data)
      }, error => console.log(error));
    this.gotoList();
  }

  onSubmit() {
    this.updateSubject(this.studentId); // use studentId property
  }
  
  gotoList() {
    this.router.navigate(['/subjects']);
  }
  onInputChange(){
  }
}
