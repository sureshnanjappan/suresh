import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ErolledStudentsComponent } from './erolled-students.component';

describe('ErolledStudentsComponent', () => {
  let component: ErolledStudentsComponent;
  let fixture: ComponentFixture<ErolledStudentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ErolledStudentsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ErolledStudentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
