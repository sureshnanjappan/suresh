import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable,} from 'rxjs';
import { Student } from './student';
import { Teacher } from './Teacher';
import { Subject } from './Subject';


@Injectable({
  providedIn: 'root'
})
export class StudentService {
  

  private url= 'http://localhost:8083/college';

  constructor(private http: HttpClient) { }

  //Student CRUD
  getStudent(id: number): Observable<any> {
    return this.http.get(`${this.url}/student/${id}`);
  }

  createStudent(student: Student): Observable<any> {         
      
    return this.http.post(`${this.url}/student`, student);
  }

  updateStudent(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.url}/student/${id}`, value);
  }

  deleteStudent(id: number): Observable<any> {
    return this.http.delete(`${this.url}/student/${id}`, { responseType: 'text' });
  }

  getStudentList(): Observable<any> {
    return this.http.get(`${this.url}/student`);
  }

  //Teacher CRUD
  getTeacher(id: number): Observable<any> {
    return this.http.get(`${this.url}/teacher/${id}`);
  }
  createTeacher(teacher: Teacher): Observable<any> {         
      
    return this.http.post(`${this.url}/teacher`, teacher);
  }
  updateTeacher(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.url}/teacher/${id}`, value);
  }
  deleteTeacher(id: number): Observable<any> {
    return this.http.delete(`${this.url}/teacher/${id}`, { responseType: 'text' });
  }
  getTeacherList(): Observable<any> {
    return this.http.get(`${this.url}/teacher`);
  }

  //Subject CRUD

  getSubject(id: number): Observable<any> {
    return this.http.get(`${this.url}/subject/${id}`);
  }
  createSubject(subject:Subject): Observable<any> {         
      
    return this.http.post(`${this.url}/subject`, subject);
  }
  updateSubject(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.url}/subject/${id}`, value);
  }
  deleteSubject(id: number): Observable<any> {
    return this.http.delete(`${this.url}/subject/${id}`, { responseType: 'text' });
  }
  getSubjectList(): Observable<any> {
    return this.http.get(`${this.url}/subject`);
  }
//Assigning Teacher and Student To the subject

assignTeacher(subid:number,teachid: number): Observable<Object> {
  return this.http.put(`${this.url}/subject/${subid}/teacher/${teachid}`,teachid);
}

}