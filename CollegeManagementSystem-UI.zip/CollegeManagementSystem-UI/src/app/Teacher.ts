export class Teacher {
    
    teacherId!:number;
    teacherName!:string;
    teacherSalery!:number;


}