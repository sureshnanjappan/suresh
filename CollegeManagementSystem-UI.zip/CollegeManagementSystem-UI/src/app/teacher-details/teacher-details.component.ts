import { Component, OnInit } from '@angular/core';
import { Teacher } from '../Teacher';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-teacher-details',
  templateUrl: './teacher-details.component.html',
  styleUrls: ['./teacher-details.component.css']
})
export class TeacherDetailsComponent implements OnInit {

  id!: number;
teacher!: Teacher;
  isnotnull:boolean=false;

  constructor(private route: ActivatedRoute,private router: Router,
    private es: StudentService) { }

  ngOnInit() {

    this.teacher = new Teacher();
    this.isnotnull=true;
    this.id = this.route.snapshot.params['id'];
    
    this.es.getTeacher(this.id)
      .subscribe(data => {
        console.log(data)
        this.teacher = data;
      }, error => console.log("server not responding"));
  }

teacher_list(){
    this.router.navigate(['teachers']);
  }
}
