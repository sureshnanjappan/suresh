import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentListComponent } from './student-list/student-list.component';
import { CreateStudentComponent } from './create-student/create-student.component';

import { StudentDetailsComponent } from './student-details/student-details.component';
import { UpdateStudentComponent } from './update-student/update-student.component';
import { TeacherListComponent } from './teacher-list/teacher-list.component';
import { CreateTeacherComponent } from './create-teacher/create-teacher.component';
import { UpdateTeacherComponent } from './update-teacher/update-teacher.component';
import { TeacherDetailsComponent } from './teacher-details/teacher-details.component';
import { SubjectListComponent } from './subject-list/subject-list.component';
import { CreateSubjectComponent } from './create-subject/create-subject.component';
import { UpdateSubjectComponent } from './update-subject/update-subject.component';
import { SubjectDetailsComponent } from './subject-details/subject-details.component';


const routes: Routes = [
{ path: '', redirectTo: 'student', pathMatch: 'full' },
  { path: 'students', component: StudentListComponent },
  { path: 'add-emp', component: CreateStudentComponent },
  { path: 'update-emp/:id', component: UpdateStudentComponent },
  { path: 'emp-detail/:id', component: StudentDetailsComponent },
  { path: 'teachers', component: TeacherListComponent },
  { path: 'add-teach', component: CreateTeacherComponent },
  { path: 'update-teach/:id', component: UpdateTeacherComponent },
  { path: 'teach-detail/:id', component: TeacherDetailsComponent },
  { path: 'subjects', component: SubjectListComponent },
  { path: 'add-subj', component: CreateSubjectComponent},
  { path: 'update-subj/:id', component: UpdateSubjectComponent },
  { path: 'subj-detail/:id', component: SubjectDetailsComponent },
 
 

];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }