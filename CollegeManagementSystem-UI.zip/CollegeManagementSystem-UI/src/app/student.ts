export class Student {
    studentId!:number
    studentName!: string;
    studentMobileNo!: string;
    studentAddress!: string;
    studentEmail!: string;
    studentAge!:number;
    studentFees!:number;
}