import { Component, OnInit } from '@angular/core';
import { Subject } from '../Subject';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-update-subject',
  templateUrl: './update-subject.component.html',
  styleUrls: ['./update-subject.component.css']
})
export class UpdateSubjectComponent implements OnInit {

  id!: number;
  subject!: Subject;
  submitted = false; // define the submitted property

  constructor(private route: ActivatedRoute, private router: Router,
              private StudentService: StudentService) { }

  ngOnInit() {
    this.subject = new Subject();
debugger
    this.id = this.route.snapshot.params['id'];

    this.StudentService.getSubject(this.id)
      .subscribe(data => {
        console.log(data)
        this.subject = data;
      }, error => console.log(error));
  }

  updateSubject() {
    this.StudentService.updateSubject(this.id, this.subject)
      .subscribe(data => console.log(data), error => console.log(error));
    this.gotoList();
  }

  onSubmit() {

    this.submitted = true;
    this.updateSubject();
  }

  gotoList() {
    this.router.navigate(['/subjects']);
  }
}
