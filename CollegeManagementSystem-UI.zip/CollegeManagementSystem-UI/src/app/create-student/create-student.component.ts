import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { StudentService } from '../student.service';
import { Student } from '../student';

@Component({
  selector: 'app-create-student',
  templateUrl: './create-student.component.html',
  styleUrls: ['./create-student.component.css']
})
export class CreateStudentComponent implements OnInit {
student: Student=new Student();
 
constructor(private es: StudentService,
    private router: Router) { }
ngOnInit() {
  }

save() {
  
    this.es.createStudent(this.student)
      .subscribe((data:any) => {
        
        alert('posted successfully')}, error => {
         
          alert('server not responding')});
    
    this.gotoList();
  }
gotoList() {
    this.router.navigate(['/students']);
  }
}